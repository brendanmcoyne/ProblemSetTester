#include "game.h"
#include "buffer.h"
#include "file_loader.h"

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <fcntl.h> 
#include <unistd.h>
#include <math.h>
#include <time.h>

/* typedef struct P player; */
/* typedef struct T treasure; */

void new_game() {
  srand(time(NULL));

  char c;
  printf("Input character icon: ");
  scanf("%c", &c);
  getchar();
  
  
  player o1 = {0,0,c};
  treasure o2 = {rand() % 10, rand() % 10,'C',((float) (rand() % 1000)) / 100, '$'};

  play_game(o1,o2);
}

void save_game(player p, treasure t) {
    Buffer *b = new_buffer();
    serialize_P(&p, b);
    serialize_T(&t, b);

    char filepath[100];
    printf("Filepath to save?: ");
    scanf("%s", filepath);
    
    
    int fd = open(filepath,  O_RDWR | O_CREAT | O_TRUNC, 0644);
    serialize_file(fd, b);
    printf("size: %ld %ld %ld\n", b->size, b->top, sizeof(struct Y));
 
    close(fd);

}

void print_board(player p) {
  for(int i = 0; i < 10; i++) {
    for(int j = 0; j < 10; j++) {
      if(p.x == j && p.y == i) {
	printf(" %c ", p.icon);
      } else {
	printf(" x ");
      }
    }
    printf("\n");
  }
}

void play_game(player p, treasure t) {
  while(1) {
    print_board(p);

    printf("Command [u,d,l,r,s]: ");
    char c;
    scanf("%c", &c);
    getchar();
  
    switch(c) {
    case 'u':
      p.y--;
      break;
    case 'd':
      p.y++;
      break;
    case 'r':
      p.x++;
      break;
    case 'l':
      p.x--;
      break;
    case 's':
      save_game(p,t);
      break;
    default:
      printf("ERROR: unrecognized command\n");
      return;
    }
    
    if(p.x == t.x && p.y == t.y) {
      printf("FOUND TREASURE!! WORTH: %c%f\n",t.currency, t.value);
      break;
    } else {
      printf("YOU ARE %d MOVES AWAY FROM TREASURE\n", abs(p.x - t.x) + abs(p.y-t.y));
    }
  }
}

void load_game() {
  printf("Saved Game Filepath?: ");
  char filepath[100];
  scanf("%s", filepath);
  getchar();
  
  printf("Loading game from %s", filepath);

  player o1;
  treasure o2;
  
  Buffer *nb = new_buffer();
  int fd2 = open(filepath, O_RDWR, 0644);
  deserialize_file(fd2, nb);

  deserialize_T(&o2, nb);
  deserialize_P(&o1,nb);

  

  play_game(o1,o2);
}

int main(void) {
  printf("New Game (N) or Load Game (L)?: ");

  char opt;
  scanf("%c", &opt);
  getchar();
  
  if(opt == 'N') {
    new_game();
  } else if (opt == 'L') {
    load_game();
  } else {
    printf("ERROR: unrecognized option\n");
    return 1;
  }
  
}
