#include "buffer.h"

struct P {
  int x;
  int y;
  char icon;
};

struct T {
  int x,y;
  char icon;
  float value;
  char currency;
};

struct Y {
    int n;
    char a;
};

struct X {
    int n, m;
    char a;
    float b;
    char c;
};

struct linked_list {
    struct node* head;
    int len;
};

struct node {
    int data;
    struct node* next;
};

void serialize_X(struct X *x, struct Buffer *output);
void deserialize_X(struct X *x, struct Buffer *input);

void serialize_Y(struct Y *y, struct Buffer *output);
void deserialize_Y(struct Y *y, struct Buffer *input);

void serialize_P(struct P *p, struct Buffer *output);
void deserialize_P(struct P *p, struct Buffer *input);

void serialize_T(struct T *t, struct Buffer *output);
void deserialize_T(struct T *t, struct Buffer *input);


void serialize_linked_list(struct linked_list *ll, struct Buffer *output);
void deserialize_linked_list(struct linked_list *ll, struct Buffer *output);

