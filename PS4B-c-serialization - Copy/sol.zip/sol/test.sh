binary=build/test

make clean; make

if [[ ! -a $binary ]]; then
    echo "FAIL: $binary not made"
    echo "SCORE: 0/10"
    exit -1
fi
score=0

echo "./build/test"
./build/test > /dev/null
score=$?

echo "SCORE: $score/11"
